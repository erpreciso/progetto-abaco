$(window).ready(function(){
    $(document).on('click',"#pubblicazione #titolo",function(){
        alert("funziona");
		aggiungi_tasto_submit();
		cambia_in_input("titolo","titolo_messaggio");
    });
    $(document).on('click',"#pubblicazione #contenuto",function(){
        alert("funziona");
		aggiungi_tasto_submit();
		cambia_in_textarea("contenuto","corpo_messaggio");
    });

    $(document).on('click',"#retrHTML",function(){
        alert($("body").html());
    });
    $(document).on('click',"#content",function(){
        alert("content fired");
    });
});

function cambia_in_input(
							nome_div_contenitore,
							nome_input
							) {
	var box = document.getElementById(nome_div_contenitore);
	var contenuto = box.innerHTML;
	if ($(box).children().length > 0) { return };
	box.innerHTML = "<input name='" + nome_input + "' value='" + contenuto + "' />";
	return;
};
function cambia_in_textarea(
							nome_div_contenitore,
							nome_textarea
							) {
	var box = document.getElementById(nome_div_contenitore);
	var contenuto = box.innerHTML;
	if ($(box).children().length > 0) { return };
	box.innerHTML = "<textarea name='" + nome_textarea + "'>" + contenuto + "</textarea>";
	return;
};
function aggiungi_tasto_submit(){
	if (document.getElementById("submit") != null) { return; };
	var pubb = document.getElementById("pubblicazione");
	var cont = pubb.innerHTML;
	frm = document.createElement("form");
	$(frm).attr("method", "POST");
	inp = document.createElement("input");
	$(inp).attr("type", "submit");
	$(inp).attr("id", "submit");
	frm.innerHTML = cont;
	frm.appendChild(inp);
	pubb.innerHTML = "";
	pubb.appendChild(frm);
};

function test(){
	alert("ciao");
};
