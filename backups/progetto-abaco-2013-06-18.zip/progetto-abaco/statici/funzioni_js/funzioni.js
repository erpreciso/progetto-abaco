var glob = "ciao";
function creaDiv(
			classe,
			id = null
			){
	var res = document.createElement("div");
	$(res).attr("class", classe);
	if (id != null) {
		$(res).attr("id", id);
	};
	return res;
}

function creaDivInput(
			nome_input,
			tabindex,
			placeholder,
			classe,
			etichetta,
			richiesto = false,
			tipo = "text",
			id = null
			){
	var res = creaDiv(classe);
	var inp = document.createElement("input");
	$(inp)
		.attr("name", nome_input)
		.attr("type", tipo)
		.attr("placeholder", placeholder)
		.attr("tabindex", tabindex)
		;
	if (richiesto) {
		$(inp).attr("required", "required");
	};
	if (id != null) {
		$(inp).attr("id", id);
	};
	$(res).append("<label>" + etichetta + "</label>");
	$(res).append(inp);
	return res;
}

function creaDivSelect(
			nome_select,
			tabindex,
			classe,
			etichetta,
			options
			){
	var res = creaDiv(classe);
	var inp = document.createElement("select");
	inp.innerHTML = options;
	$(inp)
		.attr("name", nome_select)
		.attr("tabindex", tabindex)
		;
	$(res).append("<insImg></insImg>");
	$(res).append("<label>" + etichetta + "</label>");
	$(res).append(inp);
	return res;
}

function creaFormInserimentoImmagine(){
	var contatore = document.getElementsByTagName("insImg").length;
	var tabindex_start = 6;		// numero di elementi prima del blocco immagine
	// TODO tabindex non va
	var hr = document.createElement("hr");
	var blocco_inserimento = creaDiv(
			classe = "inserimento_immagine",
			id = "blocco_immagini_" + String(contatore + 1)
			);
	var categoria = creaDivSelect(
			nome_select = "categoria_immagine",
			tabindex = contatore * 5 + tabindex_start + 1,
			classe = "inserimento_categoria",
			etichetta = "Inserisci la categoria",
			options = "<option>Principale</option><option>Vetrina</option>"
			);
	var autore = creaDivInput(
			nome_input = "autore_immagine",
			tabindex = contatore * 5 + tabindex_start + 2,
			placeholder = "inserisci qui il nome della fonte dell'immagine",
			classe = "inserimento_autore",
			etichetta = "Fonte"
			);
	var link = creaDivInput(
			nome_input = "link_immagine",
			tabindex = contatore * 5 + tabindex_start + 3,
			placeholder = "inserisci qui il link al quale posso trovare l'immagine",
			classe = "inserimento_link",
			etichetta = "Link"
			);
	var didascalia = creaDivInput(
			nome_input = "didascalia_immagine",
			tabindex = contatore * 5 + tabindex_start + 4,
			placeholder = "inserisci qui la didascalia che avrà l'immagine al passaggio del mouse",
			classe = "inserimento_didascalia",
			etichetta = "Didascalia"
			);
	var corpo_immagine = creaDivInput(
			nome_input = "corpo_immagine",
			tabindex = contatore * 5 + tabindex_start + 5,
			placeholder = "inserisci il percorso del file immagine",
			classe = "inserimento_immagine",
			etichetta = "Immagine",
			richiesto = true,
			tipo = "file",
			id = "corpo_" + String(contatore + 1)
			);
	blocco_inserimento
		.appendChild(categoria)
		.appendChild(autore)
		.appendChild(link)
		.appendChild(didascalia)
		.appendChild(corpo_immagine)
		.appendChild(hr)
		;
	$("#blocco_notizia").append(blocco_inserimento);
}

function controllo_testo_inserito_in_pubblicazione(){
	var a1 = $("input[name='autore_messaggio']").val();
	var a2 = $("input[name='etichette_pubblicazione']").val();
	var a3 = $("input[name='titolo_messaggio']").val();
	var a4 = $("textarea[name='corpo_messaggio']").val();
	var a5 = $("input[name='autore_messaggio']").val();
	var a6 = $("input[name='link_messaggio']").val();
	if (a1 && a2 && a3 && a4 && a5 && a6)
		{return true;}
	else
		{return false;}
}

function controllo_blocco_immagine(tipo_controllo){
	var contatore = document.getElementsByTagName("insImg").length;
	var categorie = $(":input[name='categoria_immagine']").serializeArray();
	var autori = $(":input[name='autore_immagine']").serializeArray();
	var links = $(":input[name='link_immagine']").serializeArray();
	var didascalie = $(":input[name='didascalia_immagine']").serializeArray();
	var corpo = $('input[id="corpo_' + String(contatore) + '"]').val();
	
	var indice_ultima_immagine = contatore - 1;
	
	if (tipo_controllo == "pieno")
		{
		if (autori[indice_ultima_immagine].value && links[indice_ultima_immagine].value && didascalie[indice_ultima_immagine].value && corpo)
			{return true;}
		else
			{return false;}
			}
	else if (tipo_controllo == "vuoto")
		{
		if (autori[indice_ultima_immagine].value || links[indice_ultima_immagine].value || didascalie[indice_ultima_immagine].value || corpo)
			{return false;}
		else
			{return true;}
			}
}

function testFunction(){
	res = $("form").html();
	alert(res);
}

function semaforo_inserimento_nuova_immagine(){
	// CONTROLLO CHE L'IMMAGINE PRECEDENTE SIA STATA INSERITA
	var res = false;
	var contatore = document.getElementsByTagName("insImg").length;
	//CASO PRIMA IMMAGINE
	if ((contatore == 0) && (controllo_testo_inserito_in_pubblicazione() == true))
		{res = true}
	//CASO IMMAGINI SUCCESSIVE
	if ((contatore > 0) && (controllo_testo_inserito_in_pubblicazione() == true) && (controllo_blocco_immagine("pieno") == true))
		{res = true}
	return(res);
}

$(document).ready(function(){
	$("#buttonInsertImg").click(function(){
		if (semaforo_inserimento_nuova_immagine())
		{
			creaFormInserimentoImmagine();
			}
		else if (controllo_blocco_immagine("vuoto") == true)
		{
			//elimina il blocco immagini
			var contatore = document.getElementsByTagName("insImg").length;
			$("#blocco_immagini_" + String(contatore)).remove();
			}
	});
	$("#testButton").click(function(){testFunction();});
})
