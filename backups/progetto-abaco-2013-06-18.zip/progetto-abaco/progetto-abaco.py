# coding: utf-8
# copyright Stefano Merlo
# [progetto-abaco] website

import webapp2
import jinja2
import random
import string
import json
import os
import unicodedata
from google.appengine.ext import ndb, blobstore
from google.appengine.ext.webapp import blobstore_handlers
from google.appengine.api import images
from time import localtime, strftime, sleep
from oggetti import *

# funzioni

def generatore_id_casuale(
			size = 6,
			chars = string.ascii_uppercase + string.digits
			):
	return ''.join(random.choice(chars) for x in range(size))
def converti_unicode_in_ascii(testo):
	res = ''
	nkfd_form = unicodedata.normalize('NFKD', unicode(testo))
	q = u"".join([c for c in nkfd_form if not unicodedata.combining(c)])
	res = ''.join(e for e in q if e.isalnum())
	return res
def questo_istante():
	"""restituisce data e ora in questo istante, formato 'yyyy-mm-dd HH-MM-SS'"""
	return strftime("%Y-%m-%d %H:%M:%S", localtime())
def contenuti_per_etichetta(nome_ascii_etichetta):
	"""restituisce la lista dei contenuti che hanno l'etichetta ascii passata, altrimenti None"""
	q = ndb.Query(Etichetta).filter('nome_ascii_etichetta = ', nome_ascii_etichetta)
	if q.get() == None:
		return None
	else:
		res = []
		for e in q:
			q2 = ndb.Query(Contenuto).filter('titolo_contenuto = ', e.titolo_contenuto)
			for e2 in q2:
				res.append(estrai_ultimo_contenuto(e2))
		return res
def contenuti_per_autore(autore_contenuto):
	q = ndb.Query(Contenuto).filter('autore_contenuto = ', autore_contenuto)
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		return res
def tutti_titoli_ascii_contenuto():
	"""restituisce la lista dei titoli ascii contenuto presenti nel datastore, altrimenti None"""
	l = Contenuto.query()
	if l:
		res = []
		for p in l:
			res.append(p.titolo_ascii_contenuto)
		return res
	return None
def tutte_etichette():
	"""restituisce la lista delle etichette presenti nel datastore in forma di dizionario {etichetta,etichetta formattata}, altrimenti None"""
	l = ndb.Query(Etichetta)
	if l:
		res = []
		for e in l:
			res.append({
					'text': e.nome_etichetta,
					'ascii': e.nome_ascii_etichetta,
					})
		return res
	return None
def oggetto_articolo(id_articolo):
	"""restituisce un oggetto articolo corrispondente al id inserito"""
	return ndb.Query(Articolo).filter('id_articolo = ', id_articolo).get()
def estrai_ultimo_contenuto(oggetto_articolo):
	"""restituisce il contenuto più recente figlio dell'articolo"""
	q = ndb.Query(Contenuto).ancestor(oggetto_articolo.key()).order("data_contenuto")
	if q.get() == None:
		return None
	else:
		return q.get()
def url_immagine(oggetto_immagine, dimensione=None):
	"""restituisce url dell'immagine della dimensione specificata, numero o 'max'"""
	if dimensione == 'max':
		dimensione_pixel = 1600
	else:
		dimensione_pixel = dimensione
	if oggetto_immagine and oggetto_immagine.blob_immagine:
		return images.get_serving_url(oggetto_immagine.blob_immagine, size=dimensione_pixel)
	return None
def immagine_principale_del_contenuto(oggetto_contenuto):
	"""restituisce l'immagine principale del contenuto, oppure None"""
	q = ndb.Query(ImmaginePrincipale).ancestor(oggetto_contenuto.key())
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		assert len(res) == 1
		return res[0]
def immagini_vetrina_del_contenuto(oggetto_contenuto):
	"""restituisce la lista delle immagini vetrina del contenuto, oppure None"""
	q = ndb.Query(ImmagineVetrina).ancestor(oggetto_contenuto.key())
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		return res
def articolo_del_contenuto(oggetto_contenuto):
	"""dell'oggetto contenuto passato, ricava l'articolo madre"""
	return ndb.Model.get(oggetto_contenuto.parent().key())
def etichette_per_contenuto(titolo_contenuto):
	"""restituisce la lista delle etichette associate ad un contenuto"""
	q = ndb.Query(Etichetta).filter('titolo_contenuto = ', titolo_contenuto)
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p.nome_etichetta)
		return res

class GestoreHTML(webapp2.RequestHandler):
	template_dir = os.path.join(os.path.dirname(__file__), 'pagine')
	jinja_env = jinja2.Environment(
		loader = jinja2.FileSystemLoader(template_dir),
		autoescape = True,
		trim_blocks = True,
		#lstrip_blocks = True,
		)
	def scrivi(self, *a, **kw):
		self.response.out.write(*a, **kw)
	
	def leggi(self,param):
		return self.request.get(param)
		
	def render_str(self, template, **params):
		return self.jinja_env.get_template(template).render(params)
		
	def render(self, template, **kw):
		self.scrivi(self.render_str(template, **kw))
	
	def servi_pagina(self, template, **kw):
		self.scrivi(self.render_str(template,**kw))

class PaginaTop10(GestoreHTML):
	def scrivi_top10(self, criterio, valore = None):
		
		#if criterio == 'data':
			#assaggi = ultimi10_assaggi()
		#elif criterio == 'etichetta':
			#assaggi = assaggi_per_etichetta(valore)
		#elif criterio == 'autore':
			#assaggi = assaggi_per_autore(valore)
		self.servi_pagina("top10.html",
						stile = "/statici/stili/top10.css",
						js = "/statici/funzioni_js/top10.js",
						contenuti = ultimi_contenuti(10),
						#stile = '"/statici/stili/top10.css"',
						#altezza = 350,
						#assaggi = assaggi,
						#etichette = lista_etichette(),
						#tdebug = assaggi,
						)

def ultimi_contenuti(quanti):
	q = Contenuto.query().order(-Contenuto.data_contenuto)
	if q.get():
		return q.fetch(quanti)
	else:
		return None

class PaginaUltimi10(PaginaTop10):
	def get(self, foo):
		self.scrivi_top10('data')

class PaginaUltimiPerEtichetta(PaginaTop10):
	def get(self, etichetta):
		self.scrivi_top10('etichetta', etichetta)

class PaginaUltimiPerAutore(PaginaTop10):
	def get(self, autore):
		self.scrivi_top10('autore', autore)

class PaginaArticolo(GestoreHTML):
	def scrivi_articolo(self,
			nuovo_articolo,
			#pubblicazione,
			#etichette,
			#immagine_principale,
			#immagini_vetrina,
			):
		#if immagine_principale:
			#img_principale = {
				#'blobkey': immagine_principale.key(),
				#'url': url_immagine(immagine_principale,600),
				#}
		#else:
			#img_principale = None
		#if immagini_vetrina:
			#img_vetrina = [{'blobkey': img.key(), 'url': url_immagine(img,600)} for img in immagini_vetrina]
		#else:
			#img_vetrina = None
		#messaggio = estrai_ultimo_messaggio(pubblicazione)
		json_data = open("liste/liste.json").read()
		data = json.loads(json_data)
		self.servi_pagina("articolo.html",
							stile = "/statici/stili/articolo.css",
							js = "/statici/funzioni_js/articolo.js",
							contenuto = None,
							nuovo_articolo = nuovo_articolo,
							upload_url = blobstore.create_upload_url('/upload'),
							#altezza = None,
							#pubblicazione = pubblicazione,
							#messaggio = messaggio,
							#etichette_pubblicazione = etichette,
							#etichette = lista_etichette(),
							#img_principale = img_principale,
							#img_vetrina = img_vetrina,
							)

	def get(self, nome_ascii_contenuto):
		if nome_ascii_contenuto == "":
			nuovo_articolo = True
		else:
			nuovo_articolo = False
		self.scrivi_articolo(
					nuovo_articolo,
					)

	def post(self, nome_ascii_contenuto):
		pass

#class PaginaJsonPubblicazione(GestoreHTML):
	#def get(self, nome_pubblicazione):
		#pubb = estrai_pubblicazione(nome_pubblicazione)
		#outp = crea_json(pubb)
		#self.response.headers['Content-Type'] = 'application/json; charset=utf-8'
		#self.scrivi(json.dumps(outp))

class PaginaChiSono(GestoreHTML):
	def get(self):
		in_costruzione = '<h1 style="color:red;font-family:monospace;">Pagina in costruzione</h1>'
		self.scrivi(in_costruzione)

class CaricaInserimento(blobstore_handlers.BlobstoreUploadHandler):
	def post(self):
		adesso = questo_istante()
		titolo_contenuto = self.request.get("titolo_contenuto")
		titolo_ascii_contenuto = converti_unicode_in_ascii(titolo_contenuto)
		lista = tutti_titoli_ascii_contenuto()	# controllo se l'id è univoco
		if lista:
			while titolo_ascii_contenuto in lista:
				titolo_ascii_contenuto = titolo_ascii_contenuto + '-' + generatore_id_casuale()
		
		nomi_etichetta = self.request.get_all("nome_etichetta")
		for k in range(len(nomi_etichetta)):
			etichetta = Etichetta()
			etichetta.titolo_ascii_contenuto = titolo_ascii_contenuto
			etichetta.nome_etichetta = nomi_etichetta[k]
			etichetta.nome_ascii_etichetta = converti_unicode_in_ascii(nomi_etichetta[k])
			etichetta.put()
		
		nomi_fonte = self.request.get_all("nome_fonte")
		links_fonte = self.request.get_all("link_fonte")
		for k in range(len(nomi_fonte)):
			fonte = FonteContenuto()
			fonte.titolo_ascii_contenuto = titolo_ascii_contenuto
			fonte.nome_fonte = nomi_fonte[k]
			fonte.nome_ascii_fonte = converti_unicode_in_ascii(nomi_fonte[k])
			fonte.link_fonte = links_fonte[k]
			fonte.put()
		
		stati_contenuto = self.request.get_all("stato_contenuto[]")
		for k in range(len(stati_contenuto)):
			stato = StatoContenuto()
			stato.titolo_ascii_contenuto = titolo_ascii_contenuto
			stato.stato_contenuto = stati_contenuto[k]
			stato.stato_ascii_contenuto = converti_unicode_in_ascii(stati_contenuto[k])
			stato.put()

		articolo = Articolo(
			).put()
		
		contenuto = Contenuto(
			parent = articolo,
			data_contenuto = adesso,
			autore_contenuto = self.request.get("autore_contenuto"),
			titolo_contenuto = titolo_contenuto,
			titolo_ascii_contenuto = titolo_ascii_contenuto,
			sottotitolo_contenuto = self.request.get("sottotitolo_contenuto"),
			corpo_contenuto = self.request.get("corpo_contenuto"),
			lingua_contenuto = "Italiano",
			).put()
		
		# sezione IMMAGINI
		categoria_immagine = self.request.get_all("categoria_immagine")
		tipo_immagine = self.request.get_all("tipo_immagine")
		nome_caricatore_immagine = self.request.get_all("nome_caricatore_immagine")
		nome_fonte_immagine = self.request.get_all("nome_fonte_immagine")
		link_fonte_immagine = self.request.get_all("link_fonte_immagine")
		descrizione_immagine = self.request.get_all("descrizione_immagine")
		blob_immagine = self.get_uploads("blob_immagine")
		
		numero_immagini = len(tipo_immagine)
		for k in range(numero_immagini):
			if categoria_immagine[k] == "principale":
				immagine = ImmaginePrincipale(parent = articolo)
			elif categoria_immagine[k] == "vetrina":
				immagine = ImmagineVetrina(parent = articolo)
			immagine.data_immagine = adesso
			immagine.tipo_immagine = tipo_immagine[k]
			immagine.nome_caricatore_immagine = nome_caricatore_immagine[k]
			immagine.nome_ascii_caricatore_immagine = converti_unicode_in_ascii(immagine.nome_caricatore_immagine)
			immagine.nome_fonte_immagine = nome_fonte_immagine[k]
			immagine.nome_ascii_fonte_immagine = converti_unicode_in_ascii(immagine.nome_fonte_immagine)
			if blob_immagine[k]:
				immagine.blob_immagine = blob_immagine[k].key()
			else:
				immagine.blob_immagine = None
			
			immagine.put()
		
		sleep(1)
		self.redirect('/')
		
class SingolaImmagine(GestoreHTML):
	def scrivi_singola_immagine(self,immagine,chiave):
		self.render("singola_immagine.html",
					immagine = immagine,
					chiave = chiave,
					blob = url_immagine(immagine, 500),
					)
		
	def get(self,chiave):
		self.scrivi_singola_immagine(ndb.get(chiave),chiave)
		
			
	def post(self,chiave):
		db.delete(chiave)
		sleep(1)
		self.redirect("/")
	
class CancellaDatastore(GestoreHTML):
	def get(self):
		ndb.delete_multi(Contenuto.query())
		sleep(1)
		self.redirect('/')

REDIRECT_RE = r'([0-9a-zA-Z-_.+#]*)'
KEY_RE = r'((?:[a-zA-Z0-9_-]+)*)'

app = webapp2.WSGIApplication([
								('/ultimi10', PaginaUltimi10),
								('/ultimi_per_etichetta/' + REDIRECT_RE, PaginaUltimiPerEtichetta),
								('/ultimi_per_autore/' + REDIRECT_RE, PaginaUltimiPerAutore),
								('/visualizza/' + KEY_RE, SingolaImmagine),
								('/chisono', PaginaChiSono),
								('/upload', CaricaInserimento),
								('/cancella', CancellaDatastore),
								('/articolo/' + REDIRECT_RE, PaginaArticolo),
								#('/pubblicazione/json/' + REDIRECT_RE, PaginaJsonPubblicazione),
								('/' + REDIRECT_RE, PaginaUltimi10),
								], debug= True)

