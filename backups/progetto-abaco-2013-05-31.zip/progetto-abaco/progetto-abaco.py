# coding: utf-8
# copyright Stefano Merlo
# [progetto-abaco] website


import webapp2
import jinja2
import random
import string
import json
import unicodedata
from google.appengine.ext import db, blobstore
from google.appengine.ext.webapp import blobstore_handlers
from google.appengine.api import images


import os
from time import localtime, strftime, sleep

from gerarchia_pubblicazione import *

# funzioni

def generatore_id_casuale(size=6, chars=string.ascii_uppercase + string.digits):
	return ''.join(random.choice(chars) for x in range(size))

def converti_unicode_in_ascii(testo):
	res = ''
	nkfd_form = unicodedata.normalize('NFKD', unicode(testo))
	q = u"".join([c for c in nkfd_form if not unicodedata.combining(c)])
	res = ''.join(e for e in q if e.isalnum())
	return res
		
def questo_istante():
	"""restituisce data e ora in questo istante, formato 'yyyy-mm-dd HH-MM-SS'"""
	return strftime("%Y-%m-%d %H:%M:%S", localtime())

def pubblicazioni_per_filtro(filtro = None, valore = None):
	"""restituisce la lista delle pubblicazioni presenti filtrate per 
	il filtro passato e in ordine di data, altrimenti None"""
	q = db.Query(dbPubblicazione)
	if filtro:
		q.filter(filtro + ' = ', valore)
	q.order('data')
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		return res

def pubblicazioni_per_etichetta(etichetta):
	"""restituisce la lista delle pubblicazioni che hanno l'etichetta passata, altrimenti None"""
	q = db.Query(dbEtichetta).filter('etichetta = ', etichetta)
	if q.get() == None:
		return None
	else:
		res = []
		for e in q:
			q2 = db.Query(dbPubblicazione).filter('nome = ', e.nome)
			for e2 in q2:
				res.append(e2)
		return res

def pubblicazioni_per_autore(autore):
	q = db.Query(dbPubblicazione).filter('autore = ', autore)
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		return res

def lista_nomi():
	"""restituisce la lista dei nomi pubblicazione presenti nel datastore, altrimenti None"""
	l = pubblicazioni_per_filtro()
	if l:
		res = []
		for p in l:
			res.append(p.nome)
		return res
	return None

def lista_etichette():
	"""restituisce la lista delle etichette presenti nel datastore, altrimenti None"""
	l = db.Query(dbEtichetta)
	if l:
		res = []
		for e in l:
			if e.etichetta not in res:
				res.append(e.etichetta)
		return res
	return None

def estrai_pubblicazione(nome):
	"""restituisce un oggetto pubblicazione corrispondente al nome inserito"""
	return db.Query(dbPubblicazione).filter('nome = ', nome).get()

def crea_inserimento(nome):
	"""restituisce un oggetto inserimento (vedi pagina sulle classi) corrispondente al nome passato, oppure None"""
	pubb = estrai_pubblicazione(nome)
	imm = immagine_principale_della_pubblicazione(pubb)
	ins = Inserimento()
	ins.nome_pubblicazione = nome
	ins.autore_pubblicazione = pubb.autore
	ins.titolo_messaggio = pubb.titolo
	ins.corpo_messaggio = pubb.corpo
	ins.autore_messaggio = pubb.fonte_nome
	ins.link_messaggio = pubb.fonte_link
	ins.titolo_immagine = imm.titolo
	ins.didascalia_immagine = imm.descrizione
	ins.autore_immagine = imm.fonte_nome
	ins.link_immagine = imm.fonte_link
	return ins

def url_immagine(immagine, dimensione=None):
	"""restituisce url dell'immagine della dimensione specificata, numero o 'max'"""
	if dimensione == 'max':
		dimensione_pixel = 1600
	else:
		dimensione_pixel = dimensione
	if immagine and immagine.chiave_blob:
		return images.get_serving_url(immagine.chiave_blob, size=dimensione_pixel)
	return None

def immagine_principale_della_pubblicazione(pubblicazione):
	"""restituisce l'immagine principale del messaggio, oppure None"""
	q = db.Query(dbImmaginePrincipale).ancestor(pubblicazione.key())
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		assert len(res) == 1
		return res[0]

def immagini_vetrina_della_pubblicazione(pubblicazione):
	"""restituisce la lista delle immagini vetrina del messaggio, oppure None"""
	q = db.Query(dbImmagineVetrina).ancestor(pubblicazione.key())
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p)
		return res

def crea_10_assaggi(lista):
	"""della lista delle pubblicazioni passate, crea 10 assaggi nel 
	formato da passare a html con titoli, autori, etichette messaggi 
	più recenti e le rispettive miniature sotto forma di url, altrimenti None"""
	if lista == None:
		return None
	res = []
	seq = 0
	top = -50
	for pubblicazione in lista:
		if seq < 10:
			nome = pubblicazione.nome
			etichette = etichette_per_nome(nome)
			titolo = pubblicazione.titolo
			autore = pubblicazione.autore
			url_miniatura = url_immagine(immagine_principale_della_pubblicazione(pubblicazione),1000)
			top += 90
			if seq % 2 == 0:
				left = 50
				right = None
			else:
				right = 50
				left = None
			res.append({
					'seq': seq,
					'nome': nome,
					'titolo': titolo,
					'etichette': etichette,
					'autore': autore,
					'url_miniatura': url_miniatura,
					'top': top,
					'left': left,
					'right': right,
					})
			seq += 1
	return res

def ultimi10_assaggi():
	"""restituisce la lista dei 10 titoli, autori, etichette messaggi più recenti e le rispettive miniature sotto forma di url, così da essere pubblicati nella pagina iniziale, altrimenti None"""
	lista = pubblicazioni_per_filtro()
	return crea_10_assaggi(lista)

def assaggi_per_etichetta(etichetta):
	"""restituisce la lista dei 10 titoli, autori, etichette messaggi filtrati per la categoria passata e le rispettive miniature sotto forma di url, così da essere pubblicati nella pagina iniziale, altrimenti None"""
	lista = pubblicazioni_per_etichetta(etichetta)
	return crea_10_assaggi(lista)

def assaggi_per_autore(autore):
	"""restituisce la lista dei 10 titoli, autori, etichette messaggi filtrati per la categoria passata e le rispettive miniature sotto forma di url, così da essere pubblicati nella pagina iniziale, altrimenti None"""
	lista = pubblicazioni_per_autore(autore)
	return crea_10_assaggi(lista)

def etichette_per_nome(nome):
	"""restituisce la lista delle etichette associate ad un nome"""
	q = db.Query(dbEtichetta).filter('nome = ', nome)
	if q.get() == None:
		return None
	else:
		res = []
		for p in q:
			res.append(p.etichetta)
		return res

def crea_json(pubblicazione):
	"""crea il dizionario da usare nell'export json"""
	res = {
			"nome": pubblicazione.nome,
			"data": pubblicazione.data,
			"autore": pubblicazione.autore,
			"titolo": pubblicazione.titolo,
			"corpo": pubblicazione.corpo,
			"fonte_nome": pubblicazione.fonte_nome,
			"fonte_link": pubblicazione.fonte_link,
			}
	return res

class GestoreHTML(webapp2.RequestHandler):
	template_dir = os.path.join(os.path.dirname(__file__), 'pagine')
	jinja_env = jinja2.Environment(loader = jinja2.FileSystemLoader(template_dir),
		autoescape = True)
	def scrivi(self, *a, **kw):
		self.response.out.write(*a, **kw)
	
	def leggi(self,param):
		return self.request.get(param)
		
	def render_str(self, template, **params):
		return self.jinja_env.get_template(template).render(params)
		
	def render(self, template, **kw):
		self.scrivi(self.render_str(template, **kw))
	
	def servi_pagina(self, template, **kw):
		self.scrivi(self.render_str(template,**kw))

class PaginaTop10(GestoreHTML):
	def scrivi_top10(self, criterio, valore = None):
		if criterio == 'data':
			assaggi = ultimi10_assaggi()
		elif criterio == 'etichetta':
			assaggi = assaggi_per_etichetta(valore)
		elif criterio == 'autore':
			assaggi = assaggi_per_autore(valore)
		self.servi_pagina("top_10.html",
						stile = '"/statici/stili/top10.css"',
						altezza = 350,
						assaggi = assaggi,
						etichette = lista_etichette(),
						#tdebug = assaggi,
						)



class PaginaUltimi10(PaginaTop10):
	def get(self, foo):
		self.scrivi_top10('data')

class PaginaUltimiPerEtichetta(PaginaTop10):
	def get(self, etichetta):
		self.scrivi_top10('etichetta', etichetta)

class PaginaUltimiPerAutore(PaginaTop10):
	def get(self, autore):
		self.scrivi_top10('autore', autore)

class PaginaInserimento(GestoreHTML):
	def scrivi_inserimento(self):
		self.servi_pagina("inserimento.html",
					stile = '"/statici/stili/inserimento.css"',
					altezza = None,
					upload_url = blobstore.create_upload_url('/upload'),
					pubblicazione = None,
					etichette_pubblicazione = None,
					)

	def get(self):
		self.scrivi_inserimento()

class PaginaPubblicazione(GestoreHTML):
	def scrivi_pubblicazione(self, pubblicazione, etichette, immagine_principale, immagini_vetrina):
		url_immagine_principale = url_immagine(immagine_principale,300)
		url_immagini_vetrina = [url_immagine(img,300) for img in immagini_vetrina]
		self.servi_pagina("pubblicazione.html",
							stile = '"/statici/stili/pubblicazione.css"',
							altezza = 350,
							pubblicazione = pubblicazione,
							etichette_pubblicazione = etichette,
							etichette = lista_etichette(),
							url_immagine_principale = url_immagine_principale,
							url_immagini_vetrina = url_immagini_vetrina,
							chiave_immagine_principale = immagine_principale,
							chiavi_immagini_vetrina = immagini_vetrina,
							)

	def get(self, nome_pubblicazione):
		pubblicazione = estrai_pubblicazione(nome_pubblicazione)
		etichette = etichette_per_nome(nome_pubblicazione)
		immagine_principale = immagine_principale_della_pubblicazione(estrai_pubblicazione(nome_pubblicazione))
		immagini_vetrina = immagini_vetrina_della_pubblicazione(estrai_pubblicazione(nome_pubblicazione))
		self.scrivi_pubblicazione(
					pubblicazione,
					etichette,
					immagine_principale,
					immagini_vetrina,
					)

class PaginaModificaPubblicazione(GestoreHTML):
	def scrivi_modifica_pubblicazione(self, nome_pubblicazione):
		self.servi_pagina("inserimento.html",
					stile = '"/statici/stili/pubblicazione.css"',
					altezza = 600,
					upload_url = blobstore.create_upload_url('/upload'),
					pubblicazione = crea_inserimento(nome_pubblicazione),
					etichette_pubblicazione = etichette_per_nome(nome_pubblicazione),
					)

	def get(self, nome_pubblicazione):
		self.scrivi_modifica_pubblicazione(nome_pubblicazione)

class PaginaJsonPubblicazione(GestoreHTML):
	def get(self, nome_pubblicazione):
		pubb = estrai_pubblicazione(nome_pubblicazione)
		outp = crea_json(pubb)
		self.response.headers['Content-Type'] = 'application/json; charset=utf-8'
		self.scrivi(json.dumps(outp))

class PaginaChiSono(GestoreHTML):
	def get(self):
		in_costruzione = '<h1 style="color:red;font-family:monospace;">Pagina in costruzione</h1>'
		self.scrivi(in_costruzione)

class CaricaInserimento(blobstore_handlers.BlobstoreUploadHandler):
	def post(self):
		adesso = questo_istante()
		# sezione PUBBLICAZIONE
		nome = converti_unicode_in_ascii(self.request.get("titolo_messaggio"))
		lista = lista_nomi()	# controllo se l'id è univoco
		if lista:
			while nome in lista:
				nome = nome + '-' + generatore_id_casuale()
		etichette_pubblicazione = self.request.get("etichette_pubblicazione").split(';')
		for etichetta in etichette_pubblicazione:
			dbEtichetta(nome = nome, etichetta = etichetta.strip()).put()

		pubblicazione = dbPubblicazione(
			nome = nome,
			data = adesso,
			autore = self.request.get("autore_pubblicazione"),
			titolo = self.request.get("titolo_messaggio"),
			corpo = self.request.get("corpo_messaggio"),
			fonte_nome = self.request.get("autore_messaggio"),
			fonte_link = self.request.get("link_messaggio"),
			).put()
		
		# sezione IMMAGINI
		categorie_immagine = self.request.get_all("categoria_immagine")
		didascalie_immagine = self.request.get_all("didascalia_immagine")
		autori_immagine = self.request.get_all("autore_immagine")
		links_immagine = self.request.get_all("link_immagine")
		files = self.get_uploads('corpo_immagine')
		
		numero_immagini = len(categorie_immagine)
		for k in range(numero_immagini):
			if categorie_immagine[k] == "Principale":
				immagine = dbImmaginePrincipale(parent = pubblicazione)
			elif categorie_immagine[k] == "Vetrina":
				immagine = dbImmagineVetrina(parent = pubblicazione)
			immagine.descrizione = didascalie_immagine[k]
			immagine.caricatore = self.request.get("autore_pubblicazione")
			immagine.fonte_nome = autori_immagine[k]
			immagine.fonte_link = links_immagine[k]
			if files[k]:
				immagine.chiave_blob = files[k].key()
			else:
				immagine.chiave_blob = None
			immagine.data= adesso
			immagine.put()
		
		sleep(1)
		self.redirect('/')
		
class SingolaImmagine(GestoreHTML):
	def scrivi_singola_immagine(self,immagine,chiave):
		self.render("singola_immagine.html",
					immagine = immagine,
					chiave = chiave,
					blob = url_immagine(immagine, 500),
					)
		
	def get(self,chiave):
		self.scrivi_singola_immagine(db.get(chiave),chiave)
		
			
	def post(self,chiave):
		db.delete(chiave)
		sleep(1)
		self.redirect("/")
	
class CancellaDatastore(GestoreHTML):
	def get(self):
		db.delete(db.Query())
		sleep(1)
		self.redirect('/')

REDIRECT_RE = r'([0-9a-zA-Z-_.+#]*)'
KEY_RE = r'((?:[a-zA-Z0-9_-]+)*)'

app = webapp2.WSGIApplication([
								('/ultimi10', PaginaUltimi10),
								('/ultimi_per_etichetta/' + REDIRECT_RE, PaginaUltimiPerEtichetta),
								('/ultimi_per_autore/' + REDIRECT_RE, PaginaUltimiPerAutore),
								('/visualizza/' + KEY_RE, SingolaImmagine),
								('/chisono', PaginaChiSono),
								('/inserimento', PaginaInserimento),
								('/upload', CaricaInserimento),
								('/cancella', CancellaDatastore),
								('/pubblicazione/' + REDIRECT_RE, PaginaPubblicazione),
								('/pubblicazione/json/' + REDIRECT_RE, PaginaJsonPubblicazione),
								('/modifica_pubblicazione/' + REDIRECT_RE, PaginaModificaPubblicazione),
								('/' + REDIRECT_RE, PaginaUltimi10),
								], debug= True)

