$(document).ready(function(){
	$("#testButton").click(function(){
		var q = "#wrapper";
		var b = $("#log");
		b.append('<div>' + box(q).top +'</div>');
		b.append('<div>' + box(q).left +'</div>');
		b.append('<div>' + box(q).width + '</div>');
		b.append('<div>' + box(q).height + '</div>');
		});
});

function box(
				name,
				top = null,
				left = null,
				width = null,
				height = null
				){
	// restituisce, a partire dall'oggetto contenente:
	// .width	:	larghezza oggetto
	// .height	:	altezza oggetto
	// .top	:	distanza dall'alto
	// .left	:	distanza da sinistra
	if (jQuery.type(name) == "string")
		{ var box = $(name); }
	else if (jQuery.type(name) == "object")
		{ var box = name; }
	res = new Object();
	res.width = box.width();
	res.height = box.height();
	res.top = box.position().top;
	res.left = box.position().left;
	res.type = jQuery.type(name);
	if (top) 
		{ 
			box.css('position','absolute');
			box.css('top',top);
			}
	return res;
};
