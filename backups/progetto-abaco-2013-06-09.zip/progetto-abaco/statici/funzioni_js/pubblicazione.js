$(window).ready(function(){
	$(document).on('click', "#pubblicazione .mod", function(){
		
		
		mess = $(this).text() 
				+ "\n" + jQuery.type($(this));
		alert(mess);
	});
    //$(document).on('click',"#pubblicazione #titolo",function(){
        //alert("funziona");
		//aggiungi_tasto_submit();
		//cambia_in_input("titolo","titolo_messaggio");
    //});
    //$(document).on('click',"#pubblicazione #contenuto",function(){
        //alert("funziona");
		//aggiungi_tasto_submit();
		//cambia_in_textarea("contenuto","corpo_messaggio");
    //});

    $(document).on('click',"#retrHTML",function(){
        crea_form();
        alert($("body").html());
    });
});

//Appunti su FORM
//1. usa il tag <fieldset>
//<form>
  //<fieldset>
    //<legend>Fruit juice size</legend>
    //<p>
      //<input type="radio" name="size" id="size_1" value="small" />
      //<label for="size_1">Small</label>
    //</p>

//2. usa il tag legend e label
//<form>	
  //<p>
    //<input type="checkbox" id="taste_1" name="taste_cherry" value="1">
    //<label for="taste_1">I like cherry</label>
  //</p>

function test(){
	alert("ciao");
};

function crea_form(){
	// salva i vecchi valori di tutti i campi
	var old_titolo = $("#titolo").text();
	var old_etichette = new Array;
	var all_etichette = $("#etichette").children(".etichetta");
	$(all_etichette).each(function(){
		old_etichette.push($.trim($(this).text()));
	});
	var old_corpo = $("#contenuto").text();
	
	// rimuove tutta la pubblicazione
	$("#pubblicazione").empty();
	
	// crea la nuova pubblicazione ma sotto forma di form
	var elm_form = $(document.createElement("form"))
		.attr("enctype", "multipart/form-data")
		.attr("method", "POST")
		.attr("action", "upload url");
		
	// crea le singole sezioni
		// titolo
	var elm_div_titolo = $(document.createElement("div"))
		.attr("id", "titolo");
	var elm_inp_titolo = $(document.createElement("input"))
		.attr("name", "titolo_messaggio")
		.attr("type", "text")
		.attr("value", old_titolo);
		// info pubblicazione
	var elm_div_info_pubblicazione = $(document.createElement("div"))
		.attr("id", "info_pubblicazione");
		// data
	var elm_div_data = $(document.createElement("div"))
		.attr("id", "data")
		.text(formatDate(new Date(jQuery.now())));
		// non serve creare l'input in quanto la data è inserita automaticamente
		// autore
	var elm_div_autore = $(document.createElement("div"))
		.attr("id", "autore");
	var elm_inp_autore = $(document.createElement("input"))
		.attr("name", "autore_messaggio")
		.attr("type", "text")
		.attr("placeholder", "Nickname");
		// etichette
	var elm_div_etichette = $(document.createElement("div"))
		.attr("id", "etichette")
		.text("Etichette: ");
	var elm_inp_etichette = $(document.createElement("input"))
		.attr("name", "etichette")
		.attr("type", "text")
		.attr("value", old_etichette);
		// corpo
	var elm_div_corpo = $(document.createElement("div"))
		.attr("id", "contenuto");
	var elm_inp_corpo = $(document.createElement("textarea"))
		.attr("name", "corpo_messaggio")
		.attr("rows", 8)
		.text(old_corpo);
		// info_fonte
	var elm_div_info_fonte = $(document.createElement("div"))
		.attr("id", "info_fonte");
		// fonte_nome
	var elm_div_fonte_nome = $(document.createElement("div"))
		.attr("id", "fonte_nome");
	var elm_inp_fonte_nome = $(document.createElement("input"))
		.attr("name", "fonte_nome")
		.attr("type", "text");
		// fonte_link
	var elm_div_fonte_link = $(document.createElement("div"))
		.attr("id", "fonte_link");
	var elm_inp_fonte_link = $(document.createElement("input"))
		.attr("name", "fonte_link")
		.attr("type", "text");
		
	elm_form.append(
		elm_div_titolo.append(
			elm_inp_titolo)
		).append(
		elm_div_info_pubblicazione.append(
			elm_div_data
			).append(
			elm_div_autore.append(
				elm_inp_autore
				)
			)
		).append(
		elm_div_etichette.append(
			elm_inp_etichette)
		).append(
		elm_div_corpo.append(
			elm_inp_corpo)
			)
		;
	$("#pubblicazione").append(elm_form);
};

function formatDate(date) {
    var mm = date.getMonth() + 1;
    var dd = date.getDate();
    var yyyy = date.getFullYear();
    mm = (mm < 10) ? '0' + mm : mm;
    dd = (dd < 10) ? '0' + dd : dd;
    var hh = date.getHours();
    var min = date.getMinutes();
    var ss = date.getSeconds();
    hh = (hh < 10) ? '0' + hh : hh;
    min = (min < 10) ? '0' + min : min;
    ss = (ss < 10) ? '0' + ss : ss;
    return yyyy + "-" + mm + "-" + dd + " " + hh + ":" + min + ":" + ss;
}
