# -*- coding: utf-8 -*-
from google.appengine.ext import db, blobstore

class dbPubblicazione(db.Model):		# datastore contenente le pubblicazioni
	nome = db.StringProperty()			# nome univoco della pubblicazione, usato come url e integrato di un codice casuale in caso di duplicazione

class dbMessaggio(db.Model):			# datastore contenente i singoli messaggi
	data = db.StringProperty()			# data e ora di inserimento o modifica della pubblicazione
	autore = db.StringProperty()		# utente che ha pubblicato
	titolo = db.StringProperty()		# titolo della pubblicazione, e stringa principale e più importante di essa
	corpo = db.TextProperty()			# corpo della pubblicazione, contenente info e approfondimenti
	fonte_nome = db.StringProperty()	# autore o provenienza di ciò che si riporta
	fonte_link = db.StringProperty()	# link, se necessario, al materiale originale

class dbImmagine(db.Model):				# datastore contenente le immagini
	data = db.StringProperty()			# data in cui è stata caricata l'immagine
	caricatore = db.StringProperty()	# utente che ha caricato l'immagine
	fonte_nome = db.StringProperty()	# autore o provenienza di ciò che si riporta
	fonte_link = db.StringProperty()	# link, se necessario, al materiale originale
	descrizione = db.TextProperty()		# descrizione dell'immagine, che probabilmente apparirà al passaggio del mouse o come didascalia
	chiave_blob = blobstore.BlobReferenceProperty()	# corpo dell'immagine sotto forma di blob

class dbImmaginePrincipale(dbImmagine):	# datastore contenente l'immagine principale del messaggio
	pass

class dbImmagineVetrina(dbImmagine):	# datastore contenente le immagini vetrina del messaggio
	pass

class dbEtichetta(db.Model):			# datastore contenente le etichette associate ai messaggi
	nome = db.StringProperty()			# nome della pubblicazione a cui l'etichetta si riferisce
	etichetta = db.StringProperty()		# nome univoco dell'etichetta
	f_etichetta = db.StringProperty()	# nome dell'etichetta formattato in ascii in modo da essere usato come  url

# assaggio = lista di dizionari da passare in sede di visualizzazione della pagina
#'seq': seq,
#'nome': nome,
#'titolo': titolo,
#'etichette': etichette,
#'autore': autore,
#'url_miniatura': url_miniatura,
#'top': top,
#'left': left,
#'right': right,
