
$(document).ready(function(){
	// parte per tasto di inserimento di una prima immagine
	$(".parte_nascosta").hide();
	$("#bottone_inserisci_immagine").click(function(){
		$(".parte_nascosta").toggle();
		if ($("#bottone_inserisci_immagine").text() == "Inserisci un'immagine")
			{$("#bottone_inserisci_immagine").text("Rimuovi inserimento")}
			
		else
			{$("#bottone_inserisci_immagine").text("Inserisci un'immagine")}
		});
	//// ora inseriamo un'altro box inserimento nel caso cambi qualcosa
	var contatore_immagini = $("#contatore_immagini").text()
	$("[name='categoria_immagine_1']").change(function(){	//rileva quando si cambia la categoria (EVENTO)
		//var dove_appendere = "#blocco_inserimento_immagine_" + contatore_immagini;
		//contatore_immagini = contatore_immagini + 1;
		//var cosa_appendere = "blocco_inserimento_immagine_" + contatore_immagini;
		//var x = $(dove_appendere).html();
		//d = document.createElement("div");
		//$(d).attr("id", cosa_appendere)
			//.html(x)
			//.appendTo(dove_appendere)
		
		$("[name='categoria_immagine_1']")
			.clone()
			.attr("name", "ciao")
			.insertAfter("[name='categoria_immagine_1']");
		
		
		
		});
	//$("#bottone_inserisci_immagine").click(function(){
		//contatore_immagini = ++1
		//$("#contatore_immagini").text(contatore_immagini)
		//var x = $("#blocco_inserimento_immagine_1").html();
		//d = document.createElement('div');
		//$(d).attr('id', 'altra_immagine')
			//.html(x)
			//.appendTo($("#blocco_notizia"))
		
		
		//});
	
	//$(window).resize(function(){
		//$("body").css("font-size","50%");
		//});
})

