# -*- coding: utf-8 -*-

from google.appengine.ext import db, blobstore

class dbPubblicazione(db.Model):
	nome = db.StringProperty()
	data = db.StringProperty()
	autore = db.StringProperty()
	titolo = db.StringProperty()
	corpo = db.TextProperty()
	fonte_nome = db.StringProperty()
	fonte_link = db.StringProperty()

class dbImmagine(db.Model):
	nome = db.StringProperty()
	data = db.StringProperty()
	titolo = db.StringProperty()
	caricatore = db.StringProperty()
	fonte_nome = db.StringProperty()
	fonte_link = db.StringProperty()
	descrizione = db.TextProperty()
	chiave_blob = blobstore.BlobReferenceProperty()

class dbImmaginePrincipale(dbImmagine):
	pass

class dbImmagineVetrina(dbImmagine):
	pass

class dbEtichetta(db.Model):
	nome = db.StringProperty()
	etichetta = db.StringProperty()

class Inserimento():
	nome_pubblicazione = None
	autore_pubblicazione = None
	titolo_messaggio = None
	corpo_messaggio = None
	autore_messaggio = None
	link_messaggio = None
	titolo_immagine = None
	didascalia_immagine = None
	autore_immagine = None
	link_immagine = None
	files = None

ETICHETTE = {}
