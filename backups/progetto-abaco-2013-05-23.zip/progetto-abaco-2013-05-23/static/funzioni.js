
$(document).ready(function(){
$("#bottone_inserisci_immagine").hide()
})

